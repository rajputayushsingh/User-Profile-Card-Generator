# User Profile Card Generator

A full-stack form-based profile card generator using Node.js, Express and SQLite.

## Features
- User profile form
- Server-side form processing
- Dynamic profile card generation
- Skills string manipulation
- GitHub and LinkedIn links
- SQLite database storage
- GET /profiles API

## Run

```bash
npm install
npm start
```

Open: http://localhost:3000

## API

GET /profiles
