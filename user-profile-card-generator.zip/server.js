const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const db = new sqlite3.Database("./profiles.db");

db.run(`
  CREATE TABLE IF NOT EXISTS profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    bio TEXT,
    skills TEXT,
    github TEXT,
    linkedin TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

app.post("/create-profile", (req, res) => {
  const { name, bio, skills, github, linkedin } = req.body;

  if (!name || !name.trim()) {
    return res.status(400).send("Name is required");
  }

  const skillList = skills
    ? skills.split(",").map(s => s.trim()).filter(Boolean)
    : [];

  const sql = `
    INSERT INTO profiles (name, bio, skills, github, linkedin)
    VALUES (?, ?, ?, ?, ?)
  `;

  db.run(
    sql,
    [name.trim(), bio || "", skillList.join(", "), github || "", linkedin || ""],
    function (err) {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }

      res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile Card</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 30px;
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #dbeafe, #f8fafc);
    }
    .card {
      width: 100%;
      max-width: 380px;
      padding: 30px;
      text-align: center;
      background: white;
      border-radius: 22px;
      box-shadow: 0 12px 35px rgba(0,0,0,.15);
    }
    .avatar {
      width: 90px;
      height: 90px;
      margin: 0 auto 15px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background: #2563eb;
      color: white;
      font-size: 36px;
      font-weight: bold;
    }
    h1 { margin: 8px 0; color: #1e293b; }
    .bio { color: #64748b; line-height: 1.6; }
    .skills {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 8px;
      margin: 20px 0;
    }
    .skill {
      padding: 7px 12px;
      border-radius: 20px;
      background: #dbeafe;
      color: #1d4ed8;
      font-size: 13px;
    }
    .links a {
      display: inline-block;
      margin: 5px;
      padding: 9px 15px;
      border-radius: 8px;
      background: #111827;
      color: white;
      text-decoration: none;
    }
    .back {
      display: inline-block;
      margin-top: 18px;
      color: #2563eb;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="avatar">${escapeHTML(name.trim().charAt(0).toUpperCase())}</div>
    <h1>${escapeHTML(name.trim())}</h1>
    <p class="bio">${escapeHTML(bio || "No bio provided")}</p>

    <div class="skills">
      ${
        skillList.length
          ? skillList.map(skill => `<span class="skill">${escapeHTML(skill)}</span>`).join("")
          : "<span>No skills added</span>"
      }
    </div>

    <div class="links">
      ${github ? `<a href="${escapeAttribute(github)}" target="_blank" rel="noopener noreferrer">GitHub</a>` : ""}
      ${linkedin ? `<a href="${escapeAttribute(linkedin)}" target="_blank" rel="noopener noreferrer">LinkedIn</a>` : ""}
    </div>

    <a class="back" href="/">Create Another Profile</a>
  </div>
</body>
</html>
      `);
    }
  );
});

app.get("/profiles", (req, res) => {
  db.all("SELECT * FROM profiles ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json(rows);
  });
});

function escapeHTML(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttribute(str) {
  return escapeHTML(str);
}

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});